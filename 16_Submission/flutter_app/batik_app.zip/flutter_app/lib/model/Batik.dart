
class Batik{
  String name;
  String asal;
  String makna;
  String harga_rendah;
  String harga_tertinggi;
  List<String> imageUrls;

  Batik({
    this.name,
    this.asal,
    this.makna,
    this.harga_rendah,
    this.harga_tertinggi,
    this.imageUrls
  });
}